# Petty Cash Tracker

Multi-office petty cash tracker. You see everything. Your team sees only their office.

**Stack:** React · Firebase (Auth + Firestore + Storage) · Vercel

---

## Setup — do these steps in order (takes ~20 minutes total)

---

### Step 1 — Firebase project (10 min)

1. Go to [console.firebase.google.com](https://console.firebase.google.com)
2. Click **Add project** → give it a name (e.g. `petty-cash`) → Continue → Continue (disable Analytics if you want) → Create project
3. Once ready, click the **web icon (</>)** to add a web app → give it a nickname → click **Register app**
4. You'll see a `firebaseConfig` object. Copy these 6 values — you'll need them later:
   - `apiKey`
   - `authDomain`
   - `projectId`
   - `storageBucket`
   - `messagingSenderId`
   - `appId`

#### Enable Authentication
5. Left sidebar → **Authentication** → Get started → **Email/Password** → Enable → Save

#### Create Firestore database
6. Left sidebar → **Firestore Database** → Create database → **Start in test mode** → choose a region near you → Done
7. Once created, go to **Rules** tab → replace ALL the content with the Firestore rules from `firebase_rules.txt` → Publish

#### Enable Storage
8. Left sidebar → **Storage** → Get started → **Start in test mode** → Next → Done
9. Go to **Rules** tab → replace ALL the content with the Storage rules from `firebase_rules.txt` → Publish

#### Create your admin account
10. Left sidebar → **Authentication** → Users → **Add user**
11. Enter your email and a password → Add user
12. Copy the **User UID** shown in the users list (looks like: `abc123xyz...`)
13. Left sidebar → **Firestore Database** → **Start collection** → Collection ID: `users` → Next
14. Document ID: paste your User UID → Add field:
    - `email` (string) → your email
    - `isAdmin` (boolean) → `true`
    - `officeIds` (array) → leave empty for now
    - `officeId` (string) → leave empty for now
    → Save

---

### Step 2 — GitHub (3 min)

1. Go to [github.com](https://github.com) → New repository → name it `petty-cash` → Create
2. On your computer, unzip the downloaded file and run:
```bash
cd petty-cash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/petty-cash.git
git push -u origin main
```

---

### Step 3 — Vercel (5 min)

1. Go to [vercel.com](https://vercel.com) → Sign in with GitHub
2. **New Project** → Import your `petty-cash` repo
3. Before deploying, click **Environment Variables** and add all 6:

| Name | Value |
|------|-------|
| `REACT_APP_FIREBASE_API_KEY` | your apiKey |
| `REACT_APP_FIREBASE_AUTH_DOMAIN` | your authDomain |
| `REACT_APP_FIREBASE_PROJECT_ID` | your projectId |
| `REACT_APP_FIREBASE_STORAGE_BUCKET` | your storageBucket |
| `REACT_APP_FIREBASE_MESSAGING_SENDER_ID` | your messagingSenderId |
| `REACT_APP_FIREBASE_APP_ID` | your appId |

4. Click **Deploy** — Vercel builds it and gives you a URL like `petty-cash-yourname.vercel.app`
5. Open that URL, log in with your admin email/password

---

### Step 4 — Add your offices and team

Once logged in as admin:
1. Click **+ Add office** → name it (e.g. Madrid) → set opening balance
2. Click **+ Add user** → select which office → enter their email and a password
3. Share the Vercel URL + their credentials with them
4. They log in and see only their office — you see all of them

---

## Access control

- **You (admin):** see all offices, add/remove offices and users
- **Office users:** see only their assigned office, can add expenses, top-ups, reconciliations
- Firebase Security Rules enforce this at the database level — a Madrid user cannot access Barcelona data even with developer tools

## Local development

```bash
cp .env.example .env.local
# fill in your Firebase config values
npm install
npm start
```
